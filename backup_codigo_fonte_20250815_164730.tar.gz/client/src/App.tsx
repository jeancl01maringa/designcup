import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { usePixelPageTracking } from "@/hooks/use-facebook-pixel";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Categories from "@/pages/Categories";
import CategoryDetailPage from "@/pages/CategoryDetailPage";
import VideoClasses from "@/pages/VideoClasses";
import More from "@/pages/More";
import ArtworkDetail from "@/pages/ArtworkDetail";
import ArtDetailPage from "@/pages/ArtDetailPage";
import AuthPage from "@/pages/auth-page";
import LoguinPage from "@/pages/loguin-page";
import ImageUploadDemo from "@/pages/ImageUploadDemo";
import SocialSharingDemo from "@/pages/SocialSharingDemo";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { MobileSearchBar } from "@/components/layout/MobileSearchBar";
import { useMobileMenuProvider } from "@/hooks/use-mobile-menu";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import PopupDisplay from "@/components/PopupDisplay";

// Páginas públicas
import PlansPage from "@/pages/PlansPage";
import ToolsPage from "@/pages/ToolsPage";

// Admin Pages
import AdminDashboard from "@/pages/admin/Dashboard";
import PostagensPage from "@/pages/admin/PostagensPage";
import CategoriasPage from "@/pages/admin/CategoriasPage";
import PlanosPage from "@/pages/admin/PlanosPage";
import FileFormatsPage from "@/pages/admin/gerenciamento/FileFormatsPage";
import PostFormatsPage from "@/pages/admin/gerenciamento/PostFormatsPage";
import TagsPage from "@/pages/admin/gerenciamento/TagsPage";
import FerramentasPage from "@/pages/admin/gerenciamento/FerramentasPage";
import UsuariosPage from "@/pages/admin/gerenciamento/UsuariosPage";
import AssinantesPage from "@/pages/admin/gerenciamento/AssinantesPage";
import MarketingPage from "@/pages/admin/MarketingPage";
import PopupsPage from "@/pages/admin/PopupsPage";
import MonetizacaoPage from "@/pages/admin/gerenciamento/MonetizacaoPage";
import SuportePage from "@/pages/admin/configuracoes/SuportePage";
import PersonalizarPage from "@/pages/admin/configuracoes/PersonalizarPage";
import ProfilePage from "@/pages/account/ProfilePage";
import CurtidasPage from "@/pages/account/CurtidasPage";
import SalvosPage from "@/pages/account/SalvosPage";
import SeguindoPage from "@/pages/account/SeguindoPage";
import EdicoesRecentesPage from "@/pages/account/EdicoesRecentesPage";
import AssinaturaPage from "@/pages/account/AssinaturaPage";
import PublicProfilePage from "@/pages/ProfilePage";
import TodasArtes from "@/pages/TodasArtesOptimized";
import AssinaturasPage from "@/pages/admin/AssinaturasPage";
import CursosPage from "@/pages/admin/CursosPage";
import AdminModulosPage from "@/pages/admin/ModulosPage";
import EditLessonPage from "@/pages/admin/EditLessonPage";
import CursosUserPage from "@/pages/CursosPage";
import CursoDetailPage from "@/pages/CursoDetailPage";
import LessonViewPage from "@/pages/LessonViewPage";
import FirstLessonRedirect from "@/pages/FirstLessonRedirect";

function Router() {
  const [location] = useLocation();
  const isAuthPage = location.startsWith("/auth");

  return (
    <Switch>
      {/* Rotas Públicas */}
      <Route path="/" component={Home} />
      <Route path="/categorias" component={Categories} />
      <Route path="/categorias/:slug" component={CategoryDetailPage} />
      <Route path="/video-aulas" component={VideoClasses} />
      <Route path="/mais" component={More} />
      <Route path="/artwork/:id" component={ArtworkDetail} />
      <Route path="/artes/:slug" component={ArtDetailPage} />
      <Route path="/arte/:slug" component={ArtDetailPage} />
      <Route path="/preview/:id" component={ArtDetailPage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/auth/login" component={AuthPage} />
      <Route path="/auth/register" component={AuthPage} />
      <Route path="/loguin/cadastro" component={LoguinPage} />
      <Route path="/loguin" component={LoguinPage} />
      <Route path="/planos" component={PlansPage} />
      <Route path="/ferramentas" component={ToolsPage} />
      <Route path="/cursos">
        <ProtectedRoute path="/cursos" component={CursosUserPage} />
      </Route>
      <Route path="/cursos/:courseId">
        <ProtectedRoute path="/cursos/:courseId" component={CursoDetailPage} />
      </Route>
      <Route path="/cursos/:courseId/primeira-aula" component={FirstLessonRedirect} />
      <Route path="/cursos/:courseId/aula/:lessonId">
        <ProtectedRoute path="/cursos/:courseId/aula/:lessonId" component={LessonViewPage} />
      </Route>
      <Route path="/todas-artes" component={TodasArtes} />
      <Route path="/demo/upload" component={ImageUploadDemo} />
      <Route path="/demo/sharing" component={SocialSharingDemo} />
      
      {/* Rota pública de perfil */}
      <Route path="/autor/:id" component={PublicProfilePage} />
      
      {/* Rotas de Conta do Usuário */}
      <Route path="/perfil">
        <ProtectedRoute path="/perfil" component={ProfilePage} requireAdmin={false} />
      </Route>
      <Route path="/curtidas">
        <ProtectedRoute path="/curtidas" component={CurtidasPage} requireAdmin={false} />
      </Route>
      <Route path="/salvos">
        <ProtectedRoute path="/salvos" component={SalvosPage} requireAdmin={false} />
      </Route>
      <Route path="/seguindo">
        <ProtectedRoute path="/seguindo" component={SeguindoPage} requireAdmin={false} />
      </Route>
      <Route path="/edicoes-recentes">
        <ProtectedRoute path="/edicoes-recentes" component={EdicoesRecentesPage} requireAdmin={false} />
      </Route>
      <Route path="/assinatura">
        <ProtectedRoute path="/assinatura" component={AssinaturaPage} requireAdmin={false} />
      </Route>
      
      {/* Rotas Administrativas */}
      <Route path="/admin/postagens">
        <ProtectedRoute path="/admin/postagens" component={PostagensPage} requireAdmin={true} />
      </Route>
      <Route path="/admin/cursos">
        <ProtectedRoute path="/admin/cursos" component={CursosPage} requireAdmin={true} />
      </Route>
      <Route path="/admin/cursos/:courseId/modulos">
        <ProtectedRoute path="/admin/cursos/:courseId/modulos" component={AdminModulosPage} requireAdmin={true} />
      </Route>
      <Route path="/admin/aulas/:lessonId/editar">
        <ProtectedRoute path="/admin/aulas/:lessonId/editar" component={EditLessonPage} requireAdmin={true} />
      </Route>
      <Route path="/admin/categorias">
        <ProtectedRoute path="/admin/categorias" component={CategoriasPage} requireAdmin={true} />
      </Route>
      <Route path="/admin/planos">
        <ProtectedRoute path="/admin/planos" component={PlanosPage} requireAdmin={true} />
      </Route>
      <Route path="/admin/gerenciamento/formatos">
        <ProtectedRoute path="/admin/gerenciamento/formatos" component={FileFormatsPage} requireAdmin={true} />
      </Route>
      <Route path="/admin/gerenciamento/formatos-post">
        <ProtectedRoute path="/admin/gerenciamento/formatos-post" component={PostFormatsPage} requireAdmin={true} />
      </Route>
      <Route path="/admin/gerenciamento/tags">
        <ProtectedRoute path="/admin/gerenciamento/tags" component={TagsPage} requireAdmin={true} />
      </Route>
      <Route path="/admin/gerenciamento/ferramentas">
        <ProtectedRoute path="/admin/gerenciamento/ferramentas" component={FerramentasPage} requireAdmin={true} />
      </Route>
      <Route path="/admin/usuarios">
        <ProtectedRoute path="/admin/usuarios" component={UsuariosPage} requireAdmin={true} />
      </Route>
      <Route path="/admin/gerenciamento/usuarios">
        <ProtectedRoute path="/admin/gerenciamento/usuarios" component={UsuariosPage} requireAdmin={true} />
      </Route>
      <Route path="/admin/gerenciamento/assinantes">
        <ProtectedRoute path="/admin/gerenciamento/assinantes" component={AssinantesPage} requireAdmin={true} />
      </Route>
      <Route path="/admin/marketing">
        <ProtectedRoute path="/admin/marketing" component={MarketingPage} requireAdmin={true} />
      </Route>
      <Route path="/admin/marketing/popups">
        <ProtectedRoute path="/admin/marketing/popups" component={PopupsPage} requireAdmin={true} />
      </Route>
      <Route path="/admin/gerenciamento/monetizacao">
        <ProtectedRoute path="/admin/gerenciamento/monetizacao" component={MonetizacaoPage} requireAdmin={true} />
      </Route>
      <Route path="/admin/assinaturas">
        <ProtectedRoute path="/admin/assinaturas" component={AssinaturasPage} requireAdmin={true} />
      </Route>
      <Route path="/admin/configuracoes/suporte">
        <ProtectedRoute path="/admin/configuracoes/suporte" component={SuportePage} requireAdmin={true} />
      </Route>
      <Route path="/admin/configuracoes/personalizar">
        <ProtectedRoute path="/admin/configuracoes/personalizar" component={PersonalizarPage} requireAdmin={true} />
      </Route>
      <Route path="/admin">
        {location === "/admin" && <ProtectedRoute path="/admin" component={AdminDashboard} requireAdmin={true} />}
      </Route>
      
      {/* Rota 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const mobileMenuState = useMobileMenuProvider();
  const { Context, value } = mobileMenuState;
  const [location] = useLocation();
  const isAuthPage = location.startsWith("/auth");
  const isAdminPage = location.startsWith("/admin");
  const showHeaderFooter = !isAuthPage && !isAdminPage;
  
  // Facebook Pixel - tracking automático de páginas
  usePixelPageTracking();
  
  // Mostrar barra de pesquisa móvel apenas na home e na página "todas as artes"
  const showMobileSearchBar = showHeaderFooter && (location === "/" || location === "/todas-artes");

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Context.Provider value={value}>
          <div className="flex flex-col min-h-screen">
            {showHeaderFooter && <Header />}
            {showMobileSearchBar && <MobileSearchBar />}
            <main className="flex-grow">
              <Router />
            </main>
            {showHeaderFooter && <Footer />}
          </div>
          <PopupDisplay />
          <Toaster />
        </Context.Provider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
